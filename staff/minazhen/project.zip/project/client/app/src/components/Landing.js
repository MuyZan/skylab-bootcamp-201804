import React from 'react';

function Landing(props) {
    return (
        <div className="landing">
            <h1 className="landing-h1">Top 10 Travels</h1>
        </div>
    )
}

export default Landing