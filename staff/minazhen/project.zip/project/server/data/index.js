const mongoose = require("mongoose")
const models = require("./src")

module.exports = { mongoose, models }